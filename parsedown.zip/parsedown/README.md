# 基于 Parsedown 1.7.1 的优化版本

## 新增源码高亮类

```php
	public function abc($obj=[]){
		echo "This's TestFile!";
		return true;      
	}
```

* [超链接](https://m.baidu.com)
* `<code>`
* Hello Words!

> 1、这是什么？
>
> 答：这是ParseDown，一款好用的PHP-MarkDown解析器。
>
> 2、为什么要篡改源代码？
>
> 答：因为源代码不支持“源码高亮”功能，我植入一个叫“geshi.php”的高亮类。
>
> 3、github-markdown.css是什么？
>
> 答：这是github自家的MarkDown解析器用的CSS样式，风格挺好看的就拿来用了。

相关截图：

![test_微信截图_20180412043116](./img/test_微信截图_20180412043116.png)

![test2_微信截图_20180412043117](./img/test2_微信截图_20180412043117.png)

![ParseDown1_微信截图_20180412043530](./img/ParseDown1_微信截图_20180412043530.png)

![ParseDown2_微信截图_20180412043531](./img/ParseDown2_微信截图_20180412043531.png)

![geshi_微信截图_20180412043355](./img/geshi_微信截图_20180412043355.png)